import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AppTest {

    @Test
    void testAppInitialization() {
        App app = new App();
        assertNotNull(app);
        // Additional assertions can be added to verify GUI components
    }

    @Test
    void testLoginFunctionality() {
        LoginController loginController = new LoginController();
        assertTrue(loginController.validateUser("admin", "password")); // Replace with actual credentials
        assertFalse(loginController.validateUser("user", "wrongpassword"));
    }
}