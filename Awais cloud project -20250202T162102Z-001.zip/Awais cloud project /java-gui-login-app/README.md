# Java GUI Login Application

This project is a simple Java GUI login application that demonstrates the use of Java Swing for creating a user interface. It includes user authentication functionality and is structured using the Maven build system.

## Project Structure

```
java-gui-login-app
├── src
│   ├── main
│   │   ├── java
│   │   │   └── com
│   │   │       └── example
│   │   │           ├── App.java
│   │   │           ├── LoginController.java
│   │   │           └── LoginView.java
│   │   └── resources
│   │       └── application.properties
│   └── test
│       ├── java
│       │   └── com
│       │       └── example
│       │           └── AppTest.java
│       └── resources
├── pom.xml
└── README.md
```

## Getting Started

### Prerequisites

- Java Development Kit (JDK) 8 or higher
- Apache Maven

### Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd java-gui-login-app
   ```
3. Build the project using Maven:
   ```
   mvn clean install
   ```

### Running the Application

To run the application, execute the following command:
```
mvn exec:java -Dexec.mainClass="com.example.App"
```

### Usage

- Enter your username and password in the login fields.
- Click the "Login" button to authenticate.
- If the credentials are correct, you will be granted access; otherwise, an error message will be displayed.

## Testing

Unit tests are included in the project to verify the functionality of the application. To run the tests, use the following command:
```
mvn test
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.