import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.flightapi.model.Flight;
import com.flightapi.repository.FlightRepository;
import com.flightapi.service.FlightService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

class FlightServiceTest {

    @InjectMocks
    private FlightService flightService;

    @Mock
    private FlightRepository flightRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllFlights() {
        Flight flight1 = new Flight("FL123", "New York", "2023-10-01T10:00:00");
        Flight flight2 = new Flight("FL456", "Los Angeles", "2023-10-02T12:00:00");
        List<Flight> flights = Arrays.asList(flight1, flight2);

        when(flightRepository.findAll()).thenReturn(flights);

        List<Flight> result = flightService.getAllFlights();

        assertEquals(2, result.size());
        verify(flightRepository, times(1)).findAll();
    }

    @Test
    void testGetFlightById() {
        Flight flight = new Flight("FL123", "New York", "2023-10-01T10:00:00");

        when(flightRepository.findById("FL123")).thenReturn(Optional.of(flight));

        Flight result = flightService.getFlightById("FL123");

        assertNotNull(result);
        assertEquals("FL123", result.getFlightNumber());
        verify(flightRepository, times(1)).findById("FL123");
    }

    @Test
    void testAddFlight() {
        Flight flight = new Flight("FL123", "New York", "2023-10-01T10:00:00");

        when(flightRepository.save(flight)).thenReturn(flight);

        Flight result = flightService.addFlight(flight);

        assertNotNull(result);
        assertEquals("FL123", result.getFlightNumber());
        verify(flightRepository, times(1)).save(flight);
    }

    @Test
    void testDeleteFlight() {
        String flightId = "FL123";

        flightService.deleteFlight(flightId);

        verify(flightRepository, times(1)).deleteById(flightId);
    }
}