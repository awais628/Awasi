import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.flightapi.model.User;
import com.flightapi.repository.UserRepository;
import com.flightapi.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

public class UserServiceTest {

    @InjectMocks
    private UserService userService;

    @Mock
    private UserRepository userRepository;

    private User user;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        user = new User();
        user.setUsername("testUser");
        user.setPassword("testPassword");
    }

    @Test
    public void testRegisterUser() {
        when(userRepository.save(any(User.class))).thenReturn(user);
        User registeredUser = userService.registerUser(user);
        assertNotNull(registeredUser);
        assertEquals("testUser", registeredUser.getUsername());
    }

    @Test
    public void testFindUserByUsername() {
        when(userRepository.findByUsername("testUser")).thenReturn(Optional.of(user));
        Optional<User> foundUser = userService.findUserByUsername("testUser");
        assertTrue(foundUser.isPresent());
        assertEquals("testUser", foundUser.get().getUsername());
    }

    @Test
    public void testUserNotFound() {
        when(userRepository.findByUsername("unknownUser")).thenReturn(Optional.empty());
        Optional<User> foundUser = userService.findUserByUsername("unknownUser");
        assertFalse(foundUser.isPresent());
    }
}