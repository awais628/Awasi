public class FlightService {

    // Injecting the FlightRepository
    private final FlightRepository flightRepository;

    public FlightService(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    // Method to retrieve all flights
    public List<Flight> getAllFlights() {
        return flightRepository.findAll();
    }

    // Method to find a flight by its ID
    public Optional<Flight> getFlightById(Long id) {
        return flightRepository.findById(id);
    }

    // Method to save a new flight
    public Flight saveFlight(Flight flight) {
        return flightRepository.save(flight);
    }

    // Method to delete a flight by its ID
    public void deleteFlight(Long id) {
        flightRepository.deleteById(id);
    }
}