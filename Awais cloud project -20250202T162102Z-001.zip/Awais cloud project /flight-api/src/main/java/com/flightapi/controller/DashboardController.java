package com.flightapi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        // Add flight information to the model
        // model.addAttribute("flights", flightService.getAllFlights());
        return "dashboard";
    }
}