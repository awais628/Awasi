# Flight API

## Overview
The Flight API is a web application built using Spring Boot that provides functionalities for user authentication and flight management. Users can log in to access a dashboard displaying flight information.

## Features
- User login and registration
- Dashboard for viewing flight details
- CRUD operations for flight and user entities

## Technologies Used
- Java
- Spring Boot
- Thymeleaf
- Maven
- JPA (Java Persistence API)

## Project Structure
```
flight-api
├── src
│   ├── main
│   │   ├── java
│   │   │   └── com
│   │   │       └── flightapi
│   │   │           ├── FlightApiApplication.java
│   │   │           ├── controller
│   │   │           │   ├── DashboardController.java
│   │   │           │   └── UserController.java
│   │   │           ├── model
│   │   │           │   ├── Flight.java
│   │   │           │   └── User.java
│   │   │           ├── repository
│   │   │           │   ├── FlightRepository.java
│   │   │           │   └── UserRepository.java
│   │   │           └── service
│   │   │               ├── FlightService.java
│   │   │               └── UserService.java
│   │   ├── resources
│   │   │   ├── application.properties
│   │   │   └── templates
│   │   │       ├── dashboard.html
│   │   │       └── login.html
│   └── test
│       └── java
│           └── com
│               └── flightapi
│                   ├── FlightApiApplicationTests.java
│                   ├── controller
│                   │   ├── DashboardControllerTest.java
│                   │   └── UserControllerTest.java
│                   ├── service
│                   │   ├── FlightServiceTest.java
│                   │   └── UserServiceTest.java
├── pom.xml
└── README.md
```

## Setup Instructions
1. Clone the repository.
2. Navigate to the project directory.
3. Run `mvn clean install` to build the project.
4. Configure the database settings in `src/main/resources/application.properties`.
5. Run the application using `mvn spring-boot:run`.
6. Access the application at `http://localhost:8080`.

## Usage
- Navigate to the login page to authenticate.
- Once logged in, users can access the dashboard to view flight information.

## License
This project is licensed under the MIT License.