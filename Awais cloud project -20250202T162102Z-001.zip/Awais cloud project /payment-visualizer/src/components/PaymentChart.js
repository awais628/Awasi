import React, { useEffect, useState } from 'react';
import { fetchPayments } from '../services/paymentAPI';
import { Line } from 'react-chartjs-2';

const PaymentChart = () => {
    const [paymentData, setPaymentData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const getPaymentData = async () => {
            try {
                const data = await fetchPayments();
                setPaymentData(data);
            } catch (error) {
                console.error('Error fetching payment data:', error);
            } finally {
                setLoading(false);
            }
        };

        getPaymentData();
    }, []);

    const chartData = {
        labels: paymentData.map(payment => payment.date),
        datasets: [
            {
                label: 'Payments',
                data: paymentData.map(payment => payment.amount),
                borderColor: 'rgba(75,192,192,1)',
                backgroundColor: 'rgba(75,192,192,0.2)',
                borderWidth: 1,
            },
        ],
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h2>Payment Chart</h2>
            <Line data={chartData} />
        </div>
    );
};

export default PaymentChart;