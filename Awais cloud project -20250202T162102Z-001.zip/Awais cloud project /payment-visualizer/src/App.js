import React from 'react';
import PaymentChart from './components/PaymentChart';

function App() {
  return (
    <div className="App">
      <h1>Payment Visualizer</h1>
      <PaymentChart />
    </div>
  );
}

export default App;