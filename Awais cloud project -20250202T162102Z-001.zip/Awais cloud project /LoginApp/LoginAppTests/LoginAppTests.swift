import XCTest
@testable import LoginApp

class LoginAppTests: XCTestCase {

    var user: User!

    override func setUp() {
        super.setUp()
        user = User(username: "testUser", password: "testPassword")
    }

    override func tearDown() {
        user = nil
        super.tearDown()
    }

    func testUserInitialization() {
        XCTAssertEqual(user.username, "testUser")
        XCTAssertEqual(user.password, "testPassword")
    }

    func testLoginSuccess() {
        let loginViewController = LoginViewController()
        let result = loginViewController.login(username: "testUser", password: "testPassword")
        XCTAssertTrue(result)
    }

    func testLoginFailure() {
        let loginViewController = LoginViewController()
        let result = loginViewController.login(username: "wrongUser", password: "wrongPassword")
        XCTAssertFalse(result)
    }
}