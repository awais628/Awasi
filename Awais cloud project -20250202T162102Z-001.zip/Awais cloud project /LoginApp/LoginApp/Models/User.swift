struct User {
    var username: String
    var password: String
}