import SwiftUI

struct DashboardView: View {
    var body: some View {
        NavigationView {
            VStack {
                Text("Welcome to the Dashboard")
                    .font(.largeTitle)
                    .padding()
                
                Spacer()
                
                // Add additional dashboard elements here
                Text("User statistics and information will be displayed here.")
                    .padding()
                
                Spacer()
            }
            .navigationTitle("Dashboard")
        }
    }
}

struct DashboardView_Previews: PreviewProvider {
    static var previews: some View {
        DashboardView()
    }
}