import XCTest

class LoginAppUITests: XCTestCase {

    override func setUp() {
        super.setUp()
        continueAfterFailure = false
        XCUIApplication().launch()
    }

    func testLoginFlow() {
        let app = XCUIApplication()
        
        // Assuming the login screen has text fields with accessibility identifiers
        let usernameTextField = app.textFields["usernameTextField"]
        let passwordTextField = app.secureTextFields["passwordTextField"]
        let loginButton = app.buttons["loginButton"]
        
        // Test entering username and password
        usernameTextField.tap()
        usernameTextField.typeText("testUser")
        
        passwordTextField.tap()
        passwordTextField.typeText("testPassword")
        
        // Test tapping the login button
        loginButton.tap()
        
        // Verify that the dashboard is displayed
        let dashboardLabel = app.staticTexts["dashboardLabel"]
        XCTAssertTrue(dashboardLabel.exists, "Dashboard should be displayed after successful login.")
    }
}