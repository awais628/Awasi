class LoginManager:
    def __init__(self, user_db):
        self.user_db = user_db

    def authenticate_user(self, username, password):
        user = self.user_db.get(username)
        if user and user['password'] == password:
            return True
        return False

    def login_user(self, user):
        # Logic to log in the user (e.g., creating a session)
        print(f"User {user['username']} logged in successfully.")