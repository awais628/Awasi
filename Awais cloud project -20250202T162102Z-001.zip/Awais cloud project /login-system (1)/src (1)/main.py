def main():
    print("Welcome to the Login System")
    username = input("Enter your username: ")
    password = input("Enter your password: ")

    from auth.login import LoginManager
    login_manager = LoginManager()

    if login_manager.authenticate_user(username, password):
        login_manager.login_user(username)
        print("Login successful!")
    else:
        print("Invalid username or password.")

if __name__ == "__main__":
    main()