import React, { useState } from 'react';

const PaymentForm = () => {
    const [amount, setAmount] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const [expiryDate, setExpiryDate] = useState('');
    const [cvv, setCvv] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess(false);

        // Basic validation
        if (!amount || !cardNumber || !expiryDate || !cvv) {
            setError('All fields are required.');
            return;
        }

        try {
            // Call payment service to process payment
            // await paymentService.processPayment({ amount, cardNumber, expiryDate, cvv });
            setSuccess(true);
        } catch (err) {
            setError('Payment processing failed. Please try again.');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Payment Form</h2>
            {error && <div style={{ color: 'red' }}>{error}</div>}
            {success && <div style={{ color: 'green' }}>Payment successful!</div>}
            <div>
                <label>Amount:</label>
                <input type="text" value={amount} onChange={(e) => setAmount(e.target.value)} />
            </div>
            <div>
                <label>Card Number:</label>
                <input type="text" value={cardNumber} onChange={(e) => setCardNumber(e.target.value)} />
            </div>
            <div>
                <label>Expiry Date:</label>
                <input type="text" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} />
            </div>
            <div>
                <label>CVV:</label>
                <input type="text" value={cvv} onChange={(e) => setCvv(e.target.value)} />
            </div>
            <button type="submit">Pay</button>
        </form>
    );
};

export default PaymentForm;