# Login System

This project is a simple login system built with Flask that includes API to API communication. It allows users to register and log in, handling authentication and user management.

## Project Structure

```
login-system
├── src
│   ├── __init__.py
│   ├── app.py
│   ├── controllers
│   │   ├── __init__.py
│   │   └── auth_controller.py
│   ├── routes
│   │   ├── __init__.py
│   │   └── auth_routes.py
│   ├── services
│   │   ├── __init__.py
│   │   └── auth_service.py
│   └── utils
│       ├── __init__.py
│       └── api_client.py
├── requirements.txt
└── README.md
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd login-system
   ```
3. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage

1. Run the application:
   ```
   python src/app.py
   ```
2. Access the API endpoints for user registration and login.

## API Endpoints

- **POST /register**: Register a new user.
- **POST /login**: Authenticate an existing user.

## Contributing

Feel free to submit issues or pull requests for improvements or bug fixes.