from flask import Blueprint, request, jsonify
from src.controllers.auth_controller import AuthController

auth_bp = Blueprint('auth', __name__)
auth_controller = AuthController()

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    return auth_controller.login(data)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    return auth_controller.register(data)

def setup_routes(app):
    app.register_blueprint(auth_bp)