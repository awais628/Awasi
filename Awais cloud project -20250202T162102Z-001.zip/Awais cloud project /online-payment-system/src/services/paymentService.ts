export const processPayment = async (paymentDetails) => {
    try {
        const response = await fetch('https://api.paymentgateway.com/process', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(paymentDetails),
        });

        if (!response.ok) {
            throw new Error('Payment processing failed');
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error processing payment:', error);
        throw error;
    }
};

export const validatePaymentDetails = (paymentDetails) => {
    // Basic validation logic for payment details
    if (!paymentDetails.amount || !paymentDetails.method) {
        throw new Error('Invalid payment details');
    }
    return true;
};