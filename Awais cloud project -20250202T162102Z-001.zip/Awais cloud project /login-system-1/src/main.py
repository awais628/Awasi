# main.py

import tkinter as tk
from gui.login_window import LoginWindow

def main():
    root = tk.Tk()
    root.title("Login System")
    root.geometry("300x200")
    
    app = LoginWindow(root)
    root.mainloop()

if __name__ == "__main__":
    main()