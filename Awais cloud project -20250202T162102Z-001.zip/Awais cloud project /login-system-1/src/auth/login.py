class Authenticator:
    def __init__(self):
        self.users = {
            "user1": "password1",
            "user2": "password2"
        }

    def verify_credentials(self, username, password):
        if username in self.users and self.users[username] == password:
            return True
        return False

    def login(self, username, password):
        if self.verify_credentials(username, password):
            return "Login successful"
        else:
            return "Invalid username or password"