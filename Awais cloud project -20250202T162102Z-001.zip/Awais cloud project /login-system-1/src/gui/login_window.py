from tkinter import Tk, Label, Entry, Button, StringVar, messagebox

class LoginWindow:
    def __init__(self, master):
        self.master = master
        master.title("Login System")

        self.username_label = Label(master, text="Username:")
        self.username_label.pack()

        self.username = StringVar()
        self.username_entry = Entry(master, textvariable=self.username)
        self.username_entry.pack()

        self.password_label = Label(master, text="Password:")
        self.password_label.pack()

        self.password = StringVar()
        self.password_entry = Entry(master, textvariable=self.password, show='*')
        self.password_entry.pack()

        self.login_button = Button(master, text="Login", command=self.login)
        self.login_button.pack()

        self.error_message = StringVar()
        self.error_label = Label(master, textvariable=self.error_message, fg="red")
        self.error_label.pack()

    def login(self):
        username = self.username.get()
        password = self.password.get()
        
        # Here you would typically call the Authenticator class to verify credentials
        if username == "" or password == "":
            self.error_message.set("Please enter both username and password.")
        else:
            # Placeholder for actual authentication logic
            if username == "admin" and password == "password":  # Example credentials
                messagebox.showinfo("Login Successful", "Welcome!")
                self.master.quit()  # Close the window on successful login
            else:
                self.error_message.set("Invalid username or password.")